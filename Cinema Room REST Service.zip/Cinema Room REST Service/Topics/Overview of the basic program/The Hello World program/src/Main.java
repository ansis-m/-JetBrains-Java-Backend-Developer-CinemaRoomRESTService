class Main {
    public static void main(String[] in) {
        System.out.printf("Hello, World!");
    }
}